<?php
	$connectivity = mysqli_connect("localhost","root","","business_letter_db");
?>