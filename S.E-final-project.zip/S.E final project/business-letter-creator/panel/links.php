
<?php if(!(isset($_SESSION['log_id']))) echo "<script>location.replace('../');</script>";?>
<ul id="MenuBar1" class="MenuBarVertical">   
        	  <li><a href="block-letter.php">BLock Letter</a></li>  
        	  <li><a href="semi-block-letter.php">Semi-Block Letter</a></li>  
        	  <li><a href="modified-letter.php">Modified letter</a></li>
    </ul>