<script>
	location.replace('block-letter.php');
</script>