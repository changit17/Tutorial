<script>
	location.replace('login.php');
</script>